using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoSave : MonoBehaviour
{
    public static class AutoSaveOnRun
    {
        // ����
        private const string MenuNameOn = "EasyTool/Auto Save/On";
        // �ر�
        private const string MenuNameOff = "EasyTool/Auto Save/Off";
    }
}
